

document.addEventListener("DOMContentLoaded", function () {
    loadSavedData();
    setupEventListeners();
});

function setupEventListeners() {
    document.querySelectorAll("input, textarea, select").forEach(input => {
        input.addEventListener("input", updatePreview);
        input.addEventListener("change", saveData);
    });
}

function updatePreview() {
    document.querySelector("#preview-name").textContent = document.querySelector("#full-name").value || "John Doe";
    document.querySelector("#preview-email").textContent = document.querySelector("#email").value || "johndoe@example.com";
    document.querySelector("#preview-phone").textContent = document.querySelector("#phone").value || "+1234567890";
    document.querySelector("#preview-experience").textContent = document.querySelector("#experience").value || "Software Engineer at XYZ Company";
    document.querySelector("#preview-education").textContent = document.querySelector("#education").value || "Bachelor's in Computer Science";
    document.querySelector("#preview-skills").textContent = document.querySelector("#skills").value || "HTML, CSS, JavaScript";
}

function saveData() {
    let formData = {};
    document.querySelectorAll("input, textarea, select").forEach(input => {
        formData[input.id] = input.value;
    });
    localStorage.setItem("resumeData", JSON.stringify(formData));
}

function loadSavedData() {
    let savedData = localStorage.getItem("resumeData");
    if (savedData) {
        savedData = JSON.parse(savedData);
        for (let key in savedData) {
            if (document.querySelector("#" + key)) {
                document.querySelector("#" + key).value = savedData[key];
            }
        }
        updatePreview();
    }
}
