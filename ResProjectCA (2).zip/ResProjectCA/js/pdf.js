

document.addEventListener("DOMContentLoaded", function () {
    const exportButton = document.querySelector("#export-pdf");
    if (exportButton) {
        exportButton.addEventListener("click", generatePDF);
    }
});

function generatePDF() {
    const element = document.querySelector(".resume-container");
    if (!element) {
        alert("Resume content not found!");
        return;
    }
    
    html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const imgWidth = 190;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, "PNG", 10, 10, imgWidth, imgHeight);
        pdf.save("resume.pdf");
    });
}
